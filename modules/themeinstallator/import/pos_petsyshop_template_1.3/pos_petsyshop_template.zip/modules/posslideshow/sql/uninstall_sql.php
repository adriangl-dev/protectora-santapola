<?php
$sql = array();
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_slideshow`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_slideshow_lang`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_slideshow_shop`';
