<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{producttooltip}prestashop>producttooltip_c888438d14855d7d96a2724ee9c306bd'] = 'Your settings have been updated.';
$_MODULE['<{producttooltip}prestashop>producttooltip_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{producttooltip}prestashop>producttooltip_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{producttooltip}prestashop>producttooltip_640fd0cc0ffa0316ae087652871f4486'] = 'minutes';
